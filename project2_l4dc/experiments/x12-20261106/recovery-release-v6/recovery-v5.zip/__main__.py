import runpy, sys
mode = sys.argv.pop(1)
assert mode in ('formal', 'report')
runpy.run_module('recovery_driver_v5' if mode == 'formal' else 'recovery_report_v5', run_name='__main__')
