# Supplementary experiments for the L4DC paper (written by Claude, reviewed by Claude)

Owner: Chengze Xie. Reviewer: Claude (checks this folder every ~30 min tonight).
Paper: `C:\Users\24375\Projects\project2_l4dc` (read only; do NOT edit any .tex).
Algorithms to implement = the paper's Section 4 (see `sections/04-upper.tex` there,
or `project2_l4dc/experiments/provenance/paper_snapshot/`).

## Channel protocol
- Claude writes tasks here. You reply by APPENDING to `CODEX_REPLY.md` (same folder):
  a section `## X<k> <stage>` per deliverable, ending with `STATUS: <stage> DONE X<k>`.
- Stages per experiment: `PROTOCOL` -> `PILOT` -> `FORMAL` -> `REPORT`.
  Pilots/calibration may start immediately. **Formal arrays of an experiment start only
  after Claude marks its protocol `ACCEPTED` below** (Claude checks every ~30 min; if no
  answer within 60 min after your PROTOCOL DONE, you may start FORMAL for X1 and X2-CE).
- Never modify or delete earlier result folders, frozen releases, or old docs. New work
  goes to new dated folders `...-20261101`. No git push, no Overleaf.
- Compute cap for tonight: **200 SU total** across all new jobs (raised by the user at
  00:51 CDT; report running spend in every reply). If a planned item would exceed the
  cap, stop and say so. With the larger cap, prefer more independent systems/seeds and
  the optional larger cells (X2 NPG n=48, X3 CE n=32, X4) over cutting corners.

## Global fairness rules (apply to every experiment below)
F1 Budget parity: dense and truncated arms get identical primitive-transition counts,
   counting every burn-in, baseline, and evaluation transition.
F2 Same data: CE dense / truncated / adaptive / oracle-diagnostic all use the SAME OLS fit
   of the SAME prefix. NPG/PI arms use paired exogenous noise (same seeds per arm).
F3 Hyperparameters (eta, H, batch schedule, nu, number of updates, burn-in length) are
   identical across arms and FROZEN before formal runs. Any calibration is done only on
   separate pilot systems/seeds that never appear in formal runs, and the calibration
   criterion is the **dense** arm (e.g. dense stable on all pilot runs). This is
   conservative for truncation; state it in the protocol.
F4 No truth leakage: learners never read the true subspace, true singular values, A, B,
   K*, P*. Fixed-order truncation may use the true rank r (the theorem's setting).
   Adaptive variants use data only. Truth is used only for evaluation.
F5 Construction (user's requirement of 2026-10-22): A generated independently of B
   (independent random source), **open-loop unstable** (spectral radius 1.05 unless stated);
   B = U diag(s) V^T with U, V Haar from another independent source; K0 = a stabilizer
   obtained by pole placement / Schur-based correction that does NOT call K*, Q, R or any
   cost evaluator. Report for each system: rho(A), ||P_{K0}||, J(K0)-J*, and the overlap
   of K0's row space with range(V_r) (diagnostic only). Use >= 8 independent systems per
   cell (systems genuinely differ; do not rely on rotations of one system) x >= 4 sampling
   seeds, unless the protocol justifies otherwise.
F6 Failures: unstable / failed outputs count as +inf in medians; always report
   stable counts out of the full denominator. A truth-based "stop on instability" is
   allowed only as failure recording, identical for all arms; disclose it.
F7 Paper-faithful algorithms:
   - CE: one trajectory, u = -K0 x + xi, xi ~ N(0, nu^2 I), INCLUDING during burn-in;
     least squares; K = LQR(Ahat, T_r(Bhat)); dense uses Bhat.
   - NPG: K <- K - eta (R K + T_r(Zhat)); Zhat = Stein/pulse estimator (pulse at block
     start, adjacent-return difference, regression on block-start states, baseline block),
     burn-in uses the SAME pulse protocol (not nominal burn); truncation on Zhat only.
   - PI: v4 (PSD clip of Ghat, joint rank-r truncation of [G+, Zhat], two-sided
     compression, full greedy), with the same pulse estimator.
   - Adaptive CE: report BOTH (i) the paper's threshold C5*sqrt((d+log(1/delta))/N) with
     one constant C5 calibrated on pilot systems and frozen, and (ii) the existing
     split-half proxy with multiplier 1 (secondary).
F8 Report absolute gap J(K)-J* and relative gap (J(K)-J*)/(J(K0)-J*), medians + IQR, and
   paired dense/truncated ratios with system-level bootstrap intervals. Only same-system
   ratios are called gains. Budget-to-epsilon only on a grid no coarser than factor sqrt(2).
F9 Pre-registration: each PROTOCOL file fixes systems, seeds, budgets, constants,
   metrics, and the analysis before any formal run; freeze code hash.

## Experiments (priority order)

### X0 Retrieve existing data (no compute)
Copy to local the original tables still marked PENDING_GRACE for groups 01 and 04, and
the independent-A/B CE results (analysis/independent-ab-stabilizer-20261022 and
ce500-common-constants-20261022) into `project2_l4dc/experiments/` with provenance.

### X1 Redundant inputs on an unstable, independently generated plant (main Fig. a/b)
Purpose: Theorem 8 under F5. Like 10/24 E1, but A unstable and independent.
- n = 12, r = 2, m - r in {0, 2, 4, 7, 10} (m = r + (m-r)), R = I, Q = W = I.
- Fixed effective plant across m: B_m = U_r V_{r,m}^T with V_{r,m} Haar in R^m;
  K0_m = V_{r,m} K_eff + 0.25 w_m h^T, where K_eff stabilizes (A, U_r) by pole placement,
  w_m is a unit vector in ker B_m (the null term hides the action subspace in K0), h fixed.
  Verify numerically that P_{K0}, J(K0), J*, ||P* F*||_F^2 are identical across m.
  (Also run the K_null = 0 variant as a one-line control.)
- Arms: CE dense / CE trunc(r) / CE true-subspace oracle (diagnostic, labeled);
  NPG dense / trunc; PI v4 dense / trunc. Same budget per arm, as in E1 scaled to
  the new plant; NPG/PI schedule calibrated on pilot systems for the DENSE arm (F3).
- Metrics: CE true redundant cost tr{Sigma_K K^T (I-Pi_R)^T R (I-Pi_R) K} and gap;
  NPG/PI final gap; stable counts. Plot vs m - r. Also N * redundant cost at two N.
- Systems: 8 independent (A, U, h) draws x 4 sampling seeds.

### X2 Dimension scaling at exact rank (main table)
Purpose: Corollary 4 shape (factor min{n,m} replaced by r), same-system ratios.
- CE: n = m in {12, 24, 48, 96}, r = 2; and n = 24 with r in {1, 2, 4, 8}. F5 construction.
  Budgets N/(n+m) on a sqrt(2) grid from 4 to 1024 (plus burn-in). Report paired gap
  ratio dense/trunc at each N/(n+m), and budget-to-epsilon for epsilon in {0.1, 0.03}
  (absolute and relative versions).
- NPG: n = m in {12, 24} (48 if within cap), r = 2. The schedule must scale with n in the
  theory's shape (batch ~ n d / a_t^2 up to a constant); calibrate the constant on pilot
  systems so that DENSE is stable on all pilots (F3). Report final gaps and stable counts.
  If dense still fails, report it; do not change the schedule after formal runs.

### X3 Full-rank B with decaying spectrum (main Fig. c)
Purpose: Theorem 3 / Corollaries 4-5: best retained order grows with budget; adaptive CE.
- n = m = 16 (CE also n = m = 32), spectra s_j = 0.7^j and two-level (1,1,0.05,...,0.05);
  negative control: flat spectrum. F5 construction.
- CE: k in {0,1,2,3,4,6,8,12,16(,24,32)} at >= 6 budgets, both adaptive thresholds (F7).
- NPG: n = m = 12, k in {1,2,4,6,12} at 3 budgets, DENSE-calibrated schedule.
- Report the median envelope over fixed k, the adaptive curves, tau_k^2, beta_k.

### X4 (optional, only if cap allows) Robustness to nominal-redundant perturbations
Evaluate X1's learned policies (m - r = 10) on (A, B + Delta B) with Delta B V_r = 0,
||Delta B|| in {.25, .5, 1} x ||B||; 10 fixed directions; no retraining. Diagnostic only.

## Reply format for each REPORT
Tables with medians/IQR and stable counts, figure paths (PNG+SVG+CSV), the exact
configs/hashes, spend, deviations from protocol (with reasons), and any finding that
contradicts the paper's claims. Do not omit negative results.

---------------------------------------------------------------------------
## Claude's review log (Claude appends below)

- 00:51 CDT (Claude): compute cap raised from 80 SU to 200 SU by the user.

### Review 01:20 CDT (Claude) — X0, X1 protocol v1

**X0: ACCEPTED.** Retrieval only, 0 SU, hashes verified. Thank you.

**X1 protocol v1: ACCEPTED for CE (start the formal CE array now); REVISE the actor
calibration rule before formal NPG/PI.** I read `engine.py` (plant, stability_only_gain,
ce_run, collect, actor_learner, actor_run). Accepted as written:
- A1 Independent A (Haar Q, rho=1.05, sampled stable eigenvalues) and Haar U, V from
  separate streams; stability-only Schur correction without Q/R/K*/costs. Good.
- A2 Your m=r correction: zero-null control over all five m with verified invariants, and
  the 0.25-null family matched over m>r with m=r as a labeled baseline. Accepted.
- A3 Action-space overlap diagnostics (||Pi_R K0||_F^2/||K0||_F^2 and projector overlap of
  range(K0) with range(V_r)): accepted. Note for the report: with null_scale=0, K0 is a
  rank-one gain inside range(V_r) (any stabilizer must act through B); report this.
- A4 CE: exploration during the 512 burn transitions, one OLS fit shared by dense /
  truncated / adaptive / oracle diagnostic, adaptive_paper with C5 plus split proxy. Good.
- A5 Absorbing-failure padding under K0 to keep exact transition parity: accepted;
  report padding separately, never as recovery.
- A6 PI = eigh clip, joint SVD of [G+, Z], two-sided compression, full greedy: matches v4.
  NPG truncates Zhat only and keeps RK; pulse burn-in. Paired innovations
  (rng without mode). Good.

**REVISE (actor calibration, required before formal NPG/PI):** the current ladder couples
eta to the budget (eta .02 / .01 / .002 with 2048 / 8192 / 32768 base blocks) and accepts
a dense relative gap <= .95. With 64 updates at eta=.002 the policy barely moves even with
exact gradients, so both arms would look alike for a reason unrelated to truncation, and
.95 accepts "no learning". Replace by:
- R1 Step size from the paper: eta = 1/(mu_+ + 2 ||B||^2 p0_bar) with p0_bar = the max of
  ||P_{K0}|| over the formal systems (a certificate the paper assumes known; it is
  arm-independent). Record the value.
- R2 Number of updates T from the **population** (exact-gradient) NPG on the pilot systems
  only: the smallest T in {64, 96, 128, 192} such that population NPG reaches relative gap
  <= 0.05 on every pilot system and m. PI keeps 8 full greedy updates (check that
  population PI reaches <= 0.05 in 8; if not, use 12).
- R3 Then choose the batch base from {2048, 8192, 32768} (geometric growth as now) as the
  smallest for which the **dense** arm is stable on all pilot runs AND dense median
  relative endpoint gap <= 0.5. If none qualifies within cap, report and stop actor X1.
- R4 Keep everything else (pairing, padding, H=32, 16 pulse burn blocks, baseline).
Publish the resolved config/hash with the pilot report; I will accept it at the next check.

Budget: cap is 200 SU (confirmed by the user directly in his chat with me at 00:51 CDT).

### Review 01:55 CDT (Claude) — X1 CE report, X1 actor protocol v2

**X1 CE FORMAL/REPORT: ACCEPTED.** I re-derived the N=8192 medians from `all_records.csv`
(e.g. m=12, null .25: dense gap .3046, truncated .0169, oracle .0148, 32/32 stable; zero-null
redundant cost dense .0204/.0366/.2000/.2433 vs truncated .0002/.0008/.0017/.0022 for
m-r=2/4/7/10). Requests for the final CE figure (post-processing only, no new runs):
- C1 Add the theorem-normalized panel: per (system, seed) compute N*D/v* with
  v* = ||P* (A-BK*)||_F^2, then median/IQR vs m-r for dense and truncated, both N.
  The raw D mixes systems with different v*; Theorem 8 predicts N*D/v* ~ (m-r).
- C2 Panel titles say "failures 0/32 max per cell" while N=4096 has 5 failed
  trajectories per method. Put the N used in each title and the true failure counts.
- C3 Report the zero-null control next to the .25-null family in one supplementary panel.

**X1 actor protocol v2 (R1-R3): ACCEPTED as written**, including the resolved R1/R2 values
(p0_bar=55.05, eta=.0090006, population NPG T=96 with worst relative gap .0333, PI T=8).
Proceed with R3 (base 2048 -> 8192 -> 32768, dense-only criterion) and, once a base
qualifies and the measured plan fits the cap, start the formal NPG/PI arrays without
waiting for another review. If no base qualifies, report and stop actor X1.

**Next:** please write X2 and X3 PROTOCOLs now in parallel with the X1 actor runs
(reuse engine.py; CE parts are cheap). For X2-CE use the sqrt(2) grid and the fixed
N/(n+m) paired-ratio analysis; for X2-NPG reuse the R1-R3 calibration logic per n.
For X3, implement adaptive_paper (C5 calibrated on pilot systems, frozen) and the split
proxy. I will review them at the next check; CE-only protocols of X2/X3 that follow
X1's accepted CE design exactly may start formal after 60 min without my answer.

### Review 02:25 CDT (Claude) — X1 actor pilot, X2 and X3 protocols, population supplement

**X1 actor pilot / resolved config: ACCEPTED** (base 2048 qualifies on the dense criterion:
dense NPG 18/18 and PI 18/18 stable, dense relative endpoint medians .1204 and .3982;
93,308,928 primitive transitions per arm). The running formal array is approved.

**X2 protocol v1: ACCEPTED.**
- X2-CE: start the formal array as soon as the n96 pilot timing gives a plan inside the
  cap. The integer sqrt(2) grid, the >=29/32 attainment rule with right censoring, the
  system-cluster bootstrap, and labeling only within-system ratios as gains are all as
  required. Please add to the report: (i) paired dense/truncated gap ratio at fixed
  N/(n+m) in {16, 64, 256} plotted against n/r (median and bootstrap CI), and (ii) the
  same for relative gaps; no fitted "law", just the plot and table.
- X2-NPG plan (eta per n from the max-initial-P certificate, population T, schedule
  N_t = ceil(base * n(n+m)/(12*24) / a_t^2) with a_t^2 = 2^(-4t/T), dense-only base
  selection): ACCEPTED with the same conditional rule as X1 — once population T and a
  dense-qualified base exist for n=12 and n=24 and the measured plan fits the cap,
  start the formal NPG array without waiting for me, and publish the resolved
  config/hash. n=48 only if it fits after X3 is budgeted.

**X3 protocol v1: ACCEPTED.**
- X3-CE: the C5 rule (1.25 x max normalized operator error of the dense Bhat on the
  disjoint pilot fits, one global constant, frozen) is accepted; it is calibrated on
  estimation error, not on control performance, which is what I wanted. Once C5 is
  computed from the pilot, start the formal CE array without waiting for me; publish
  C5 and the resolved hash. Keep the fixed-k envelope labeled as post-hoc diagnostic.
- X3-NPG plan: ACCEPTED with the same conditional rule as X1/X2-NPG.

**Population supplement (X2/X3 eta and T): ACCEPTED.**

Priorities if the cap gets tight: X1 actors > X2-CE > X3-CE > X2-NPG n12/24 >
X3-NPG > X1 figure C1-C3 (post-processing, cheap; do it anytime) > X2-NPG n48 > X4.

### Review 03:00 CDT (Claude)

- **X1 CE report-ce-v2 (C1-C3): ACCEPTED.** The normalized medians N*D/v* for dense
  (about 2.8 / 13.0 / 20.6 / 31.4 at m-r = 2/4/7/10, N=8192) against truncated
  (0.03 / 0.12 / 0.20 / 0.40) are exactly the panel the paper needs.
- **X2-CE and X3-CE FORMAL: ACCEPTED as complete;** waiting for the REPORTs. In both
  reports, break failures down by method x N (x k for X3) and keep k=0 failures in a
  separate "diagnostic" row so that 5,747 X3 failures are not read as learning failures.
- **X2-NPG formal (base 2048, n12/24) and X3-NPG resource pilot: ACCEPTED**, as already
  permitted by the 02:25 conditional rule. X3-NPG formal may start once the measured
  plan fits; n48 remains optional and last.

### Review 03:30 CDT (Claude)

- **X2-CE REPORT: ACCEPTED.** I re-read `fixed_budget_ratios.csv`: the paired
  dense/truncated ratio rises with n/r (n/r = 3: 2.2-2.7; 6: 4.0-5.7; 12: 9.0-9.8;
  24: 15.5-18.2 at r=2 and 9.9-28.2 at r=1; 48: 25.6-33.3). These ratios are computed on
  finite pairs only, and dense fails more often than truncated, so excluding failed pairs
  is conservative for truncation; keep the finite/full counts next to every ratio in the
  final table, as you did.
- **X3-CE REPORT: ACCEPTED, including the negative result.** The paper-form threshold
  with the frozen C5 = 2.569 over-truncates the two-level spectrum (n32: relative .406 vs
  dense .058; n16: .277 vs .053) and is mixed on the smooth spectrum. Do NOT re-tune C5
  post hoc. For the paper I will report it as is. One extra post-processing table only
  (no new runs): for every (n, spectrum, N), the retained order of adaptive_paper and
  adaptive_split vs the best fixed k (median), and the paper-form threshold value next
  to the smallest retained true singular value, so the reader sees why it over-truncates.
- **X1 NPG/PI FORMAL: ACCEPTED as complete.** NPG 0 failures; PI fails 116/288 dense vs
  77/288 truncated endpoints. Please report per m-r and per null variant, both
  failure-inclusive medians and stable counts, plus the paired ratios on finite pairs.
- **X2-NPG FORMAL (n12/24, 0 unstable): ACCEPTED as complete;** report next.
- **X3-NPG formal plan (base 8192, 120 SU upper, total 160.25/200): ACCEPTED** under the
  02:25 conditional rule; go.
- **n48 deferral: ACCEPTED** (does not fit after X3; no reduced design).
- **X4: ACCEPTED** (formal + report, upper .17 SU, zero training). Run after X3-NPG is
  submitted; it is a diagnostic only.

### Review 04:05 CDT (Claude)

All of the following are **ACCEPTED** as honest reports, including the weak/mixed results:
- X1 actor report + full tables v2 + figures v3. PI: strong paired dense/truncated ratios
  (about 3.2 / 4.8 / 7.5 / 9.8 at m-r = 2/4/7/10 on finite pairs) but many failures
  (dense 116/288, truncated 77/288). NPG: all stable, but paired ratios 1.05-1.49 with
  CIs including 1.
- X2 actor report (NPG n12/24: mixed, CIs include 1) + figures v3.
- X3 CE explanation table v4 and metadata correction v5 (paper-form threshold keeps k=2
  where the best fixed k is 16/32 on the two-level spectrum; the split proxy keeps 12/23).
- X4 report (CE truncated 320/320 stable under all perturbation sizes vs dense 317/315/303).

One post-processing request (saved policies only, no new runs), because the NPG result
needs a mechanism check before I can interpret it:
- P1 For X1-NPG and X2-NPG endpoints (and the last-stage iterates), compute the true
  redundant cost D = tr{Sigma_K K^T (I-Pi_R)^T R (I-Pi_R) K} and the remaining
  action-space gap g(Pi_R K), for dense and truncated, per cell; report medians/IQR and
  the fraction D/g. Also report ||U^T (K_T - K*)||_F^2 and ||V_r^T (K_T - K*)||_F^2 split.
  Purpose: decide whether the small NPG gap ratio is because the redundant component is
  already small at the endpoint (small eta averages null-direction noise) or because the
  action-space error dominates both arms.
- P2 For the same endpoints, the population (exact-gradient) NPG relative gap at the same
  T and eta (from your R2 calibration runs, formal systems not needed: recompute on the
  formal systems with exact gradients, zero samples) so we can separate optimization error
  from statistical error.
Continue X3-NPG formal as planned; report when done.

### Review 04:35 CDT (Claude)

**P1/P2 (X1 and X2 NPG mechanism): ACCEPTED.** Thank you, this resolves the question.
Reading of the result (for the record): the redundant component is large for dense NPG
(D/g about .60-.82 in X1, .87 in X2), truncation lowers D (paired ratios 1.2-1.9 in X1,
1.85/3.15 in X2), but the truncated arm has a larger action-space gap (X2 action-gap
paired ratio .165 at n12, .298 at n24), and exact-gradient references reach .025-.054
relative gap while the sampled runs end at .1-.7. So the runs are in a high-noise regime
where the rank-r SVD of Zhat is poorly aligned, which is outside the theorem's small-error
regime (a_t <= c_1). No action needed; X3-NPG (budget multipliers 1/4/16) will show
whether the trade-off turns in favor of truncation as the noise drops. Please make sure
the X3-NPG report includes the same P1-style decomposition for the exact-rank-like
two-level spectrum (D vs action-space part relative to range of the top-2 singular
directions is not defined for full rank, so instead report, per budget multiplier, the
Frobenius error of T_k(Zhat) vs Z_K at the last stage for each k, and the endpoint gaps).

No new experiments tonight beyond X3-NPG. Remaining reserve stays unused unless X3-NPG
finishes under its bound.

### Review 05:20 CDT (Claude)
X3-NPG report protocol (own-arm last-stage ||T_k(Zhat)-Z_K||_F, common-estimate offline
diagnostic at the dense K_63, failure-inclusive endpoint summaries, 0.25 SU): **ACCEPTED**.
Run it as soon as the X3-NPG formal array completes. Spend so far 69.5 SU, fine.

### Review 07:00 CDT (Claude) — final review; overnight loop ends

**X3-NPG FORMAL and REPORT: ACCEPTED, including the negative result.** On full-rank B
with n=m=12, 31 of 36 paired dense/k intervals lie below 1 and none above 1: fixed-order
truncation of Zhat lowers the last-stage Frobenius error (two-level, x16: k1 .35 vs
dense .53 in the common-estimate branch) but dense has the best endpoint gap at the larger
budgets (best k = 12 except two-level x1, where k=4 is best). Keep the flat control.
**Final delivery: ACCEPTED.** Thank you for the careful work tonight.

The overnight loop ends here. Please do not submit any new jobs; the author will decide
next steps after reading `SELECTION_AND_RISKS.md` and Claude's summary.

---

## X5 (new task, 2026-11-01 17:00 CDT, author-approved; PI added 17:25) — NPG and PI budget escalation

The author wants the NPG and PI comparisons redone at larger budgets, escalating stage by stage.
X5 reopens job submission **for X5 only**. All fairness rules F1-F9 apply unchanged.
Same gates: PROTOCOL -> PILOT (resource only) -> FORMAL -> REPORT, each waiting for my
explicit ACCEPTED. New-job cap for X5: **380 SU requested upper bound** (separate from
the overnight 200 SU; the author may change it). Report settled and requested SU at every gate.

**What changes: only the sample budget.** Use the frozen paper-faithful NPG and PI v4 engines and the
exact X1/X2 configurations (same systems, same K0, same seeds, same eta from R1, same T from
R2, same H, same pulse burn-in/baseline structure, same nd/a_t^2 schedule shape, same paired
innovations across arms). Multiply every per-stage batch size by a budget multiplier
c in {4, 16, 64}. The existing X1/X2 formal results are rung c = 1 and are reused, not rerun.
No eta, T, H or schedule retuning at any rung; if dense becomes unstable at some rung, that
is reported, not fixed. Count all transitions, burn-in included, as before.

**Cells (no CE):**
- A: X1 zero-null family, n = 12, r = 2, m in {4, 6, 9, 12}. Primary (isolates the
  noise-driven redundant cost of Theorem `thm:separation`).
- B: X1 0.25-null family, m in {4, 6, 9, 12}. Secondary.
- C: X2 n = m = 12, r = 2.
- D: X2 n = m = 24, r = 2.
Algorithms: NPG in A, B, C, D. PI v4 in A and B only (PI has a c = 1 rung only in X1;
X2 has no calibrated PI, and X5 must not introduce new tuning). PI keeps its frozen X1
settings (PSD clip, joint SVD of [G+, Z], two-sided compression, full greedy step,
same T and batches); only the per-stage batch is multiplied by c.
Arms: dense and truncated (rank r = 2), 8 systems x 4 seeds as in X1/X2.

**Pre-registered ladder (fixed now; do not stop or extend based on outcomes):**
- Rung c = 4: A, B, C, D (NPG); A, B (PI).
- Rung c = 16: A, C, D (NPG); A (PI).
- Rung c = 64: A at m = 12 and m = 6, C (NPG); A at m = 12 and m = 6 (PI).
- If measured costs exceed the cap, drop cells only in this pre-declared order:
  NPG D at c = 16 first, then A m = 6 at c = 64 (both algorithms), then B at c = 4
  (both algorithms). NPG and PI cells in A are kept or dropped together. Never drop a cell because of
  its result. Never run a rung before the previous rung's FORMAL has been ACCEPTED (cost
  control), but the decision to continue depends only on cost, not on outcomes.

**PILOT (resource only, no science readout):** for each rung, one complete dense path per cell
at the largest system index, to measure wall time and RSS; extrapolate the rung cost with the
same 1.3x + 60 s margin. Do not inspect truncated outputs or any gap value at pilot.

**REPORT per rung, per algorithm (and a pooled table over c = 1, 4, 16, 64):**
1. Failure-inclusive median/IQR of absolute and relative endpoint gap per cell and arm; stable counts.
2. Paired dense/truncated total-gap ratio with system-cluster bootstrap 95% CI.
3. P1 decomposition at the endpoint: true D, action-space gap g(Pi_R K), D/g, paired D ratio,
   paired action-gap ratio, and ||U^T(K_T-K*)||_F^2, ||V_r^T(K_T-K*)||_F^2.
4. Alignment diagnostic at the last stage: ||Zhat - Z_K||_F / sigma_r(Z_K) and the sin-theta
   distance between the top-r right singular subspace of Zhat and that of Z_K (own arm).
   Purpose: show whether escalation moves the runs into the small-error regime a_t <= c_1.
   For PI use the same diagnostic on the compressed estimate used by the greedy step.
4b. PI only: failed endpoints and failed iterates per cell, arm and rung (failures are
   +infinity, no replacement by an earlier stable iterate), first-failure stage
   distribution, and the paired ratio both failure-inclusive and on finite pairs
   (with the finite-pair count shown beside it).
5. One figure per cell family: total-gap paired ratio (with CI) vs total transitions on a
   log axis, c = 1..64, plus the P2 population reference as a horizontal line for each arm.
State the hypothesis being tested before the FORMAL run: H1 "the paired dense/truncated
total-gap ratio increases with c and its CI lies above 1 at the largest rung in A and C."
For PI also H2 (from Remark `rem:pi-upper`/Lemma `app:lem:pi-rec`: stability holds w.h.p.
once the per-stage estimation error is below a threshold that shrinks as ||P_K0|| grows):
"failed endpoints in both arms decrease with c and vanish at the largest rung; at every rung
failures concentrate on the plants with the largest ||P_K0||." Report failures per system
next to P0_op. Truncated-vs-dense failure counts are an observation, not a hypothesis.

**P3 (before X5 PILOT; no training, saved data only, tiny cost).** At c = 1, PI endpoint
failures are 0 on systems 101/104/106/108 (P0_op 6.6/3.9/4.3/3.2) and 53/68/54/18 on
systems 102/103/105/107 (P0_op 24.7/54.5/21.3/14.7), mostly at updates 1-3, and they also
occur at m = r (10/32), where truncation is the identity. Please check:
(i) exact-model PI from the same K0 with the same 8 updates on all 8 formal plants and all
m/null cells: every iterate must be stabilizing (Hewer); any failure means a bug, stop X5;
(ii) for every PI trajectory, at the first failed update and at the update before it:
||[Ghat-G_K, Zhat-Z_K]|| (operator), ||P_K||, and the curvature-weighted step error
||(K+ - K_g)^T (R+G_K)(K+ - K_g)|| if the saved policies allow it; median/max per system;
(iii) the same quantities for NPG at the same stages, to show why NPG with small eta stays stable.
Report the result whatever its direction; if H1 or H2 fails, say so plainly.
Order: P3 report first (wait for ACCEPTED), then X5 PROTOCOL.

Start with `## X5 P3` and then `## X5 PROTOCOL` in CODEX_REPLY.md (resolved configs + hashes, per-rung cost
estimate from the measured c = 1 timings, ladder and drop order as above), then wait.

### X5 amendment 17:40 CDT (Claude, author-approved) — budget aligned with the theorem's regime

The theorems are statements in the small-error regime (NPG: ||Zhat_t - Z_{K_t}|| <= a_t <= c_1;
PI: a <= e_PI). The c = 1 runs are outside it (P2: exact-gradient relative gap .025-.054 vs
sampled .1-.7; truncated NPG relative gap grows from .057 at m = 2 to .28 at m = 12 on the
same closed loop, far more than the d = n + m growth 14 -> 24 in the rate). So X5 must
report where each run sits relative to that regime, and escalate until it is inside.

**Regime criterion (pre-registered, arm-independent, never uses gaps or stability):**
for each cell and system, let rho_T = median over the 4 seeds of
||Zhat - Z_K||_F / sigma_r(Z_K) at the last stage of the **dense** arm (for PI, the
joint estimate [Ghat, Zhat] against [G_K, Z_K] and sigma_r of [G_K, Z_K]).
A (cell, system, rung) is **in regime** if rho_T <= 1/2. The in-regime rung c*(system) is the
smallest ladder rung meeting it. Compute rho_T for c = 1 from saved data (part of P3) so we
know at once how far each system is from the regime.

**Escalation:** run the ladder as before. After c = 64, for A m in {6, 12} and C, any system
with no in-regime rung gets one more rung c = 256 for that system only (both arms, both
algorithms in A). Before submitting c = 256, report its measured cost; it needs my ACCEPTED
and, if the total would exceed 380 SU, the author's approval.

**Additional REPORT items:**
6. rho_T per (cell, system, rung, algorithm) beside P0_op.
7. An "in-regime" summary: each system at its own c*; paired ratios, D/g, action-gap ratio
   over in-regime systems only, together with the full failure-inclusive table (both shown).
8. Paired NPG ratio vs m - r next to the structural factor (m-r)n/(r(n+m)) of Theorem
   `thm:separation`(b) versus Theorem `thm:e2e`(b) (constants unknown; trend only).
9. NPG only: per-stage ||U^T K_t||_F^2 (dense and truncated) and the action-space error
   ||V_r^T(K_t - K*)||_F^2, so we can see whether the endpoint redundant component comes from
   early small-batch stages (with eta = .009 the null component contracts by 1 - eta per
   stage, so early noise is not forgotten within T = 96) or from the last stages.

### 18:20 CDT (Claude) — **X5 ON HOLD. Do not start X5 or P3.** X6 drafted below, not yet authorized.

Reason: I ran a Monte Carlo of the frozen Stein estimator (`collect`, H = 32, nu = 1,
16 burn blocks) at K = K0, outside the cluster, 6-40 replicas per setting. Results:
- The estimator is unbiased (||mean Zhat - Z||_F^2 matches var/reps in all 6 settings), so the
  NPG code has no implementation bug; sign, baseline, regression and pairing match the paper.
- The runs are far outside the theorem's regime. rho_op = ||Zhat - Z_K||_op / sigma_r(Z_K):
  X2 n12 sys201 (P0 3.6): 11 at N = 2048 blocks, 2.7 at the last-stage N = 31836;
  X2 n12 sys202 (P0 16.9): 56 at N = 2048; X2 n24 sys201 (P0 9.3): 40; X2 n24 sys202 (P0 176): 924.
  Top-2 subspace of Zhat is nearly orthogonal to the truth (sin-theta .97-.99).
- In this regime T_r(Zhat) is a biased (shrunk) estimate: <V V^T E[T_r(Zhat)], Z>/||Z||^2 =
  .49 (sys201, N 2048), .82 (N 31836), -.04 (sys202). Dense is unbiased and the small eta
  averages its noise over ~1/eta stages, so dense NPG behaves like averaged SGD, while
  truncated NPG drifts to a biased fixed point. This explains ratio ~ 1 (X1/X2) and dense
  best (X3). PI takes full steps without averaging, hence its failures on high-P0 plants.
- The generator's ||P_K0|| grows with n (median 6.8 / 13.5 / 32.0 at n = 12/24/48 over 200
  draws), so simply enlarging n makes the noise worse and confounds n with conditioning.
- Even at fixed P0 ~ 3, rho_op at N = 2048 is 10.2 (n12) vs 23.4 (n24).
Hence the X5 ladder (c <= 64, frozen eta = .009/.011/.0028) cannot reach rho_op <= 1/2 for most
plants and cannot answer the question. (Also: the regime criterion must use the operator norm,
not Frobenius; corrected in X6.)

## X6 DRAFT (do not start until Claude writes "X6 GO") — theorem-regime NPG/PI/CE, n-sweep

- Family: same generator, but a draw is kept only if ||P_K0|| <= pbar = 8 (certificate-controlled
  class; the theorems' constants depend on p0, the dimension dependence is the question).
  Same pbar for all n. Report acceptance rates. No other selection.
- n = m in {12, 24, 48}, r = 2, exact spectrum. 8 systems x 4 seeds, paired innovations.
- eta = 1/(mu_+ + 2 ||B||^2 pbar) = 1/17, same for all n (R1 with the class certificate).
  T by R2 (population NPG relative gap <= .05 on pilot plants of the same class).
- Per-stage batch: calibrated on pilot plants by the exact-model diagnostic only (never gaps,
  never the truncated arm): the smallest base such that the dense estimate at K0 has median
  rho_op <= 1/2; geometric growth as before. Lower rungs base/4 and base/16 are also run,
  to show the transition from the averaging regime to the theorem regime.
- Algorithms: CE (dense/truncated, same OLS data, same transition count), NPG, PI v4.
- Report per n and rung: gaps, paired ratios with system bootstrap, stable counts, D and
  action-space gap, rho_op and the alignment ratio along the path, and the structural factor
  (m-r)n/(r(n+m)).
- Cost: measure in PILOT first. n = 48 runs only if the measured cost fits; otherwise report.

### 18:45 CDT (Claude) — correction to the 18:20 note (still no action for Codex)
The alignment numbers .49/.82/-.04 in the 18:20 note had too few replicas (sys202 value is
noise). Replacement, n12 sys201 at K0, per-replicate projection coefficient <M, Z>/||Z||_F^2
(mean +- s.e.): dense Zhat .96+-.14 (N 2048, 60 reps), 1.03+-.05 (N 32768, 16), .98+-.03
(N 262144, 8); T_2(Zhat) .60+-.11, .72+-.06, .95+-.03. So dense is unbiased along the
signal and truncation shrinks it at low budget; the shrinkage disappears near 128x the base.
Additional: a stable-A, K0 = 0 variant of the same plants (eigenvalues <= .6) has
||P_K0|| = 1.56 for every system and rho_op = 7.6-9.6 at N = 2048 (vs 10.6/59.8/12.5 for the
unstable+pole-placement plants 201/202/203). X6 may use the Theorem `thm:lower` class
(K0 = 0, ||P_K0|| <= 2) instead of rejection sampling; the author decides.

---

## X6 GO (19:05 CDT, author-approved) — replaces X5 (X5 and P3 are cancelled; X6 DRAFT above is superseded)

All fairness rules F1-F9 apply. Gates: PROTOCOL -> PILOT (resource only) -> FORMAL -> REPORT,
each waiting for my explicit ACCEPTED, separately for X6a, X6b, X6c. New-job cap for all of
X6: **400 SU requested upper bound** (author may change it). Report settled and requested SU
at every gate. Never select, drop or retune based on gaps or on the truncated arm.

### Plant families (new system ids; pilot ids disjoint from formal ids)
- **S (certificate class of Theorem `thm:lower`):** A = Q diag(lambda) Q^T, Q Haar,
  all lambda_i ~ U(.15, .60) (no unstable mode), K0 = 0, so ||P_K0|| <= 1/(1-.36) = 1.5625 <= 2;
  B = U_r V_r^T exact rank r = 2 with Haar U, V as in `plant()`; Q = R = W = I.
  Formal ids 301-308, pilot ids 9101-9102.
- **U (current X1/X2 generator, open-loop unstable, stability-only K0):** unchanged `plant()`.
  For X6a no selection. For X6c keep a draw only if ||P_K0|| <= 15, taking ids 401, 402, ...
  in order until 8 are accepted (pilot: 9201, ... until 2); record every rejected id, the
  acceptance rate, and ||U_r^T u_1||^2 for accepted and all draws.

### X6a — estimation error at a fixed gain (no learning; main/appendix mechanism figure)
- n = m in {24, 36, 48, 72}, r = 2, families S and U, gain K = K0. (Author, 19:10: no n = 12, no n = 96.)
- Stein estimator exactly as `collect` (nu = 1, 16 burn blocks, one baseline block);
  H = 32 for U, H = 16 for S (S has spectral radius <= .6, .6^16 < 3e-4).
- Per-stage blocks N in 2048 x {1, 4, 16, 64, 256}; 8 systems x 4 seeds per (family, n, N).
  Drop the largest N at n = 72 only if the measured cost does not fit; say so.
- From the same data report (median/IQR over seeds, then over systems):
  NPG: ||Zhat - Z||_F/||Z||_F and ||T_2(Zhat) - Z||_F/||Z||_F, their paired ratio,
  rho_op = ||Zhat - Z||_op/sigma_r(Z), sin-theta of the top-2 left subspaces, and the
  projection coefficient <M, Z>/||Z||_F^2 for M = Zhat and M = T_2(Zhat) (mean +- s.e.).
  PI: the same for [G+, Zhat] versus the jointly compressed pair of `actor_learner`.
  CE: from an OLS fit on N transitions of the CE experiment (as `ce_run`), ||Bhat - B||_F/||B||_F
  and ||T_2(Bhat) - B||_F/||B||_F.
- Also report, per (family, n), the smallest N in the grid with median rho_op <= 1 on the
  pilot systems; this calibrates X6b/X6c (pilot systems only, dense estimate only).

### X6b — end-to-end on family S (main actor experiment)
- n = m in {24, 36, 48, 72}, r = 2, NPG and PI v4, dense vs truncated, paired innovations,
  8 systems x 4 seeds; failures +infinity with absorbing padding as before.
- eta = 1/(mu_+ + 2||B||^2 pbar) with pbar = 2: eta = 0.2 for every n.
  T by R2: smallest T in {16, 24, 32, 48, 64} with population NPG relative gap <= .05 on the
  S pilot systems for every n; PI 8 updates (12 if 8 do not reach .05 in population).
- H = 16, 16 burn blocks, one baseline block per stage.
- Batches: blocks_t = ceil(base_n 2^{t/16}) for NPG, with base_n = the X6a in-regime N for
  family S at that n. PI uses its geometric schedule scaled to the same total primitive
  budget as NPG (as in X1). Rungs: base_n x {1/16, 1/4, 1}, all pre-registered.
- Priority 24, 36, 48, then 72; n = 48 and n = 72 FORMAL only if their measured cost fits
  the cap; otherwise report.
- REPORT: relative gap g(K_T)/g(K0) and absolute gap (failure-inclusive median/IQR), paired
  dense/truncated ratio with system-cluster bootstrap 95% CI, stable counts, endpoint D and
  action-space gap, rho_op and the projection coefficient along the path (own arm), the
  structural factor (m-r)n/(r(n+m)), and one figure: paired ratio vs n per rung.

### X6c — open-loop-unstable check on family U with ||P_K0|| <= 15
- n = m in {24, 36}, r = 2, NPG and PI v4, same structure as X6b, 8 systems x 4 seeds.
- eta = 1/(1 + 2 x 15) = 1/31; T by R2 on the U pilot systems; H = 32;
  base_n from X6a family U in-regime N on the U pilot systems; rungs base_n x {1/4, 1}.
- Starts only after X6b n = 24, 36 FORMAL is ACCEPTED and if the cap allows.

Order: X6a PROTOCOL first (it is cheap and calibrates the rest). Start with `## X6a PROTOCOL`
in CODEX_REPLY.md: resolved configs + hashes, measured per-cell timing plan, SU estimate.

### Review 20:20 CDT (Claude) — X6a PROTOCOL v1: ACCEPTED with one amendment

Accepted as written: U ids 401-408 / pilots 9201-9202 without selection for X6a; CE in
512-transition chunks with its frozen burn and prefix stops (report Stein M = (N+17)H and
CE M = N+512 separately); PI main pair [G+, Zhat] vs the actor_learner compressed pair, raw
[Ghat, Zhat] as a separate diagnostic; seed-then-system medians, paired ratios before
aggregation, system-based s.e.; separate NPG / raw-PI / clipped-PI thresholds; explicit
right censoring; rho_op <= 1 described as an empirical precision threshold, not a
certification of the theorem's constants. Resource PILOT (2 SU requested) may start now.

**Amendment A1 (pre-registered before any numerical readout):** my local Monte Carlo on S
pilots (H = 16, N = 2048, 4 seeds) gave rho_op = 24-26 at n = 48 and 35-39 at n = 72,
i.e. rho_op <= 1 needs about 1.2-1.4e6 and 2.5-3.1e6 blocks. The grid would therefore be
right-censored for S at n >= 48, and X6b could not be calibrated there. For n in {48, 72},
both families, extend the nested Stein grid by N = 2048 x {1024, 2048}
(2,097,152 and 4,194,304 blocks). CE needs no extension. Include these cells in the
resource PILOT timing and in the measured FORMAL plan; if the measured FORMAL request
exceeds 40 SU, report before submitting.

### Review 21:50 CDT (Claude) — X6a PILOT: ACCEPTED; X6a FORMAL authorized

Resource-only pilot accepted: 8/8 cells complete, frozen-engine bitwise/rtol 1e-11
equivalence passed, exact M counts verified, no accuracy/gap/truncated readout. The measured
FORMAL plan (40 bundles = 32 formal + 8 calibration, all 8 systems x 4 seeds, A1 grid kept,
20 min/bundle, 13.33 SU requested; X6a cumulative request 16.33/400 SU) is ACCEPTED.
Submit X6a FORMAL with the analysis frozen as stated (SHA 0962905f...). After it completes,
run the REPORT (<= 1 SU) and deliver: the per-(family, n, N) tables of relative errors
(dense vs truncated, all three estimators), rho_op, sin-theta, projection coefficients,
and the pilot-only calibration N for rho_op <= 1 (with right censoring flagged). Then
propose the X6b PROTOCOL (S family, n in {24,36,48,72}) using those calibrated N.

### Note 22:55 CDT (Claude, author-approved) — additions for the X6a REPORT and the X6b PROTOCOL

**X6a, saved-data addition (no new transitions, within the REPORT or a second <= 1 SU REPORT job):**
from the saved X6a CE least-squares fits on family S (K0 = 0, fixed certificates), compute the
dense and rank-2 CE gains and their exact gaps, and report per n in {24,36,48,72} and N the
paired ratio g(dense)/g(truncated) (median and system-bootstrap 95% CI over pairs with both
stable), stable counts per arm, and the failure-inclusive version (unstable = +infinity; drop
only pairs where both are unstable, and report how many). Same for family U, with medians of
||P_K0|| and v_star per n. Purpose: CE n/r scaling at fixed certificates.

**X6b PROTOCOL must additionally include (pre-registered):**
1. Rungs base_n x {1/64, 1/16, 1/4, 1} (add 1/64 if the measured cost allows), to show the
   transition from the low-precision to the high-precision regime; base_n fixed from the
   X6a pilot-only calibration before any X6b formal run, never re-chosen from formal outcomes.
2. At every rung, both arms with identical primitive transitions: final gap (absolute and
   relative, failure-inclusive median/IQR), stable counts, paired ratio over both-stable pairs
   and the failure-inclusive version.
3. Budget-to-epsilon from the rung ladder for relative gap 0.1 and 0.05: smallest rung with
   >= 29/32 runs attaining it, per arm, right-censored, no interpolation; system bootstrap.
4. rho_op and the projection coefficient along the path are diagnostics computed with the
   simulator only; they are never inputs of the learners.

### Review 23:00 CDT (Claude) — X6a REPORT: ACCEPTED; S/n36 calibration extension authorized

X6a REPORT accepted as an estimation/mechanism result (no terminal-cost claim). Consistent
with my independent local Monte Carlo (S, N = 2048: trunc/dense error ratio rising with n;
truncated projection coefficient well below 1 at low N, near 1 at high N).
1. **S/n36 censoring:** authorized a pilot-only, dense-only NPG calibration extension on the
   S pilots 9101/9102 x the 4 calibration seeds at N = 1,048,576 and 2,097,152 blocks
   (nested, same collector). Take the smallest N with pilot median rho_op <= 1 as base_36;
   if still censored, report and keep n36 out of X6b. Do not use formal data.
2. Then run the saved-data CE addition of the 22:55 note (fixed-certificate CE ratios on S),
   and propose the X6b PROTOCOL with bases 524288 / base_36 / 2097152 / 4194304 and all
   items of the 22:55 note; measure costs per rung before any FORMAL request. X6c (U family)
   is deferred: its pilot calibration is censored everywhere, so it needs its own decision.

### Review 23:10 CDT (Claude) — X6a CE addition: ACCEPTED. X6b PROTOCOL v2: ACCEPTED for R2 and resource PILOT

CE saved-fit addition accepted (fixed-certificate S ratios 5.69/8.06/10.28/15.07 at N=524288,
32/32 stable; U disclosed with failures). Please also copy `summary.csv` and
`certificate_summary.csv` of CE-addition-v1 to `experiments/x6-20261101/CE-addition-v2/`
(the delivery path is too deep for my file bridge).

X6b PROTOCOL v2 accepted as written. Authorized now, in this order and without further
acceptance: (1) the population-only R2 resolution of T (dense population NPG/PI on the
8 S pilot plants, zero transitions, 1/12 SU); if no T in {16,24,32,48,64} qualifies, stop and
report; (2) the resource-only PILOT (<= 4 SU, no accuracy/performance readout), including the
1/64 rung cost. Then post the resolved T, integer schedules and the measured FORMAL plan, and
wait for explicit FORMAL acceptance. If the full plan exceeds the remaining cap, propose the
pre-declared cut order (72 first, then 48), never cutting systems/seeds/rungs per outcome.

### Review 00:30 CDT (Claude) — X6b PILOT: ACCEPTED; X6b FORMAL: ACCEPTED

Resource pilot accepted (equivalence PASS for NPG and PI, all 32 (n, rung, algorithm) cells
timed, no performance readout). The measured FORMAL plan is ACCEPTED as posted: all four
dimensions n = 24/36/48/72, all four rungs 1/64, 1/16, 1/4, 1, NPG T = 16 and PI T = 8,
eta = 0.2, systems 301-308 x seeds 1701-1704, 12 arrays x 32 tasks, requested upper
317.87 SU plus 6.5 SU report reserve (cumulative 343.37/400 SU). Analysis frozen at the
listed SHAs. Submit now. Report progress per array; if an array fails for an infrastructure
reason, report before any resubmission (no automatic retry). After all arrays complete, run
the frozen REPORT and post the per-rung tables required by the 22:55 note.

### Review 10:10 CDT (Claude) — X6b REPORT: ACCEPTED

Accepted as reported, including failures and censoring. Key reading: at the full rung, paired
dense/truncated gap ratios NPG 3.98/5.67/7.89/11.32 and PI 21.6/29.9/44.3/66.0 for
n = 24/36/48/72, all arms 32/32 stable; all 198 failures are dense PI at rungs 1/64 and 1/16,
truncated 0/1024; truncated NPG attains relative 0.1 on the ladder (n24 with censored
bootstrap mass), not 0.05; truncated PI attains both; dense never attains either.
Please copy the summary CSV(s) behind the per-rung table and attainment.csv into
`experiments/x6-20261101/X6b-report-v1/` (if not already there at <= 7 folder depth) so the
paper figure can be regenerated from them. No further runs are requested at this time; X6c stays
deferred.

---

## X7 GO (16:55 CDT 11/02, author-approved) — effective rank for CE at fixed certificates

Purpose: the paper's central quantity is the eps-effective actuation rank k_eps(B). Show, for a
FULL-RANK B with decaying singular values and fixed system certificates, that (i) CE truncated at a
fixed order k has a gap that trades off k*d/N against the tail tau_k^2, so the best order grows
with N; (ii) a well-chosen truncation beats dense CE by a large factor when N is moderate;
(iii) how the data-driven thresholds of Corollary `cor:adaptive-rate` behave. CE only, no actors.
Same gates PROTOCOL -> PILOT (resource only) -> FORMAL -> REPORT; cap 15 SU (X6 cap unaffected).

Design (pre-registered; never select or retune on gaps):
- Family S exactly as X6 (A = Q diag(lambda) Q^T, lambda_i ~ U(.15,.60), K0 = 0, ||P_K0|| <= 1.5625;
  Q = R = W = I, nu = 1, burn 512, CE engine and OLS exactly as frozen `ce_run`).
- n = m in {24, 48}. B = U diag(sigma) V^T with Haar U, V (independent streams as in plant()),
  sigma_1 = 1 and two spectra: geometric sigma_j = 0.7^(j-1), and polynomial sigma_j = 1/j.
  Report tau_k^2 and beta_k for every k.
- Regression budgets N = 4d x {1, 4, 16, 64, 256, 1024} transitions (d = n + m), nested prefixes of
  one continuous trajectory; report N and N + 512.
- Arms from the same OLS fit at each prefix: dense; fixed k in {1,2,3,4,6,8,12,16,24,32,48}
  (k < min(n,m)); adaptive_paper (threshold C5 sqrt((d + log(1/delta))/N), C5 = 2.569, delta = .05,
  as in X3); adaptive_split (half-sample proxy, as in X3); and a pre-registered sensitivity of the
  paper-form constant C in {0.5, 1.0} labeled "sensitivity, not selection".
- 8 formal systems x 4 seeds per (n, spectrum); new system ids 501-508, pilots 9501-9502.
- REPORT: failure-inclusive absolute and relative gap g/g(K0) (median/IQR), stable counts; for each
  (n, spectrum, N): the post-hoc best fixed k (labeled post hoc, not available to the learner),
  the paired ratio dense/k for every fixed k and for both adaptive rules (both-stable and
  failure-inclusive, system-bootstrap 95% CI); the order chosen by each adaptive rule (median/IQR);
  and the check whether gap scales as 1/N within each arm (slope of log gap vs log N).
  Copy all summary CSVs to `experiments/x7-20261102/` at <= 3 folder depth for the paper figure.
Start with `## X7 PROTOCOL` in CODEX_REPLY.md. Resource PILOT may start right after my ACCEPTED.

## X7 review (17:30 CDT 11/02) — PROTOCOL ACCEPTED

X7 PROTOCOL ACCEPTED. I checked `## X7 PROTOCOL` (config SHA e35d5a95...b572165f, SHA256SUMS
5c5eefcb...a0fb995a) against X7 GO: family S with fixed certificates, n = m in {24, 48}, both spectra,
budgets 4d x {1,...,1024} (192..196608 and 384..393216), fixed k < n (n48 adds 24, 32), dense,
adaptive_paper with the literal C5 = 2.569 and delta = .05 (accepted as written; no recalibration),
adaptive_split, sensitivity C in {0.5, 1.0} labeled "sensitivity, not selection", ids 501-508 x seeds
1801-1804, pilots 9501/9502, one shared OLS fit per prefix, frozen analysis (failure-inclusive medians,
both ratio definitions, common-draw system bootstrap, post hoc best k including dense and best
truncated separately, slopes over all six and last three budgets, tau_k^2 and beta_k for all k). All match.

Authorizations, in order:
1. Resource PILOT (<= 1 SU) as described, as soon as the Grace connection is restored by the author.
   No gap/stability/rank readout from the pilot.
2. FORMAL is ACCEPTED in advance IF the measured formal plan (32 bundles at the resolved limit) is
   <= 12 SU and RSS headroom >= 20%. Post the measured plan and hashes, then submit without waiting.
   If the measured plan exceeds 12 SU, stop and wait for my explicit FORMAL ACCEPTED.
3. REPORT (<= 2 SU) is ACCEPTED to follow FORMAL automatically, with the frozen analysis above. Copy
   the summary CSVs directly into `experiments/x7-20261102/` (no deeper than 3 folders).
No automatic retries; no grid cut. X7 cap stays 15 SU.

## X7 review (23:55 CDT 11/04) — REPORT ACCEPTED; X8 QUERY (author request, no compute)

**X7 REPORT: ACCEPTED as reported**, including the negative results: the paper-form threshold
(C5 = 2.569) is conservative and loses to dense at the largest N (n24 geometric .7793, n24
polynomial .4903, n48 polynomial .2476), and the polynomial spectrum returns to dense at large N.
I read the post hoc best fixed order (geometric 1,4,6,8,12,12 for both n) and the moderate-N
k4 ratios 2.066 / 3.966 as reported. No further X7 runs.

**X8 QUERY (no compute, no new jobs, no deletion or move of any file).** The author is
redesigning the main CE figure around two questions:
- (b) rank sweep: at fixed n = m, how the number of transitions needed to reach a target
  relative gap (0.05 and 0.02) scales with r = rank B, dense vs truncated at k = r;
- (c) spectrum sweep: for full-rank B with sigma_j = rho^(j-1), how that number scales with
  k_eps(B).
Please answer under `## X8 QUERY` in CODEX_REPLY.md:
- Q1 Which existing results on Grace can serve (b) or (c), including results not yet copied to
  the local folder? For each: path, experiment id, construction family, n, m, r or spectrum,
  budget grid, arms, systems x seeds, and whether record-level data (system, seed, N, arm, gap)
  exist.
- Q2 Can the X2-CE records (n = 24, r in {1,2,4,8}) and the X7 records be re-analyzed post hoc
  into a median-curve budget-to-target (log-log interpolation of the median relative gap over
  the system x seed population, no 29/32 rule)? List the cells that would remain censored.
- Q3 Feasibility only (SU and wall time; do NOT submit): an X8 DRAFT with the frozen family-S CE
  engine (as X7: K0 = 0, nu = 1, burn 512, one OLS fit per nested prefix), n = m = 48,
  N = 2^9, ..., 2^18, 8 systems x 4 seeds, new system ids;
  (b) sigma = r ones, r in {1,2,4,8,16,32,48}, arms dense and truncated k = r;
  (c) sigma_j = rho^(j-1), rho in {0.3,0.5,0.7,0.8,0.9,0.95}, arms dense and every fixed k in 1..47.
  X8 stays a draft until I write "X8 GO".
- Q4 Please confirm that no folder holding X0-X7 records, fits, policies or releases is part of
  any Grace cleanup or archive-then-delete plan, and keep them excluded.

## X9 QUERY (22:10 CDT 11/05) — NPG/PI with approximately low-rank B (no compute)

Author request: the main text now supports the effective-rank claim for CE with full-rank spectra
(X8), but NPG and PI are tested only at exact rank 2 (X6b). We plan one more experiment that
connects the exact-rank results with full-rank B for NPG and PI. **This is a draft. Do not submit
anything; X9 starts only after I write "X9 GO".** Please answer under `## X9 QUERY` in CODEX_REPLY.md.

DRAFT design (please comment):
- Family S and the X6b NPG/PI engine, schedule, stage counts, and four budget rungs
  N_cal/64, N_cal/16, N_cal/4, N_cal of the X6b cell n = m = 24, unchanged.
- B = U diag(sigma) V^T with the X6b system ids (same A, U, V), sigma_1 = sigma_2 = 1 and
  sigma_3 = ... = sigma_24 = alpha, alpha in {0, 0.02, 0.05, 0.1, 0.2}, so that
  tau_2^2 = 22 alpha^2 in {0, 0.0088, 0.055, 0.22, 0.88}.
- Arms: dense and truncated k = 2, for NPG and for PI; 8 systems x 4 seeds; paired noise as in X6b.
- Report per cell: absolute and relative gap medians and IQR, stabilizing counts, first-failure
  stages, redundant-cost share where defined, paired ratios, and every failure.

Questions:
- Q1 SU and wall time for a pilot and for the formal run, and the earliest completion if started
  tomorrow morning (deadline for figures: Nov 10).
- Q2 Is alpha = 0 identical to the X6b n = 24 cell (same systems, seeds, engine)? If so, can it be
  reused instead of rerun?
- Q3 Given the X6b n = 24 medians at N_cal (truncated NPG 0.0149, truncated PI 0.0058, dense NPG
  0.0579, dense PI 0.124, absolute gaps), is the alpha grid well placed to show where the benefit of
  truncation shrinks and disappears? Suggest a better grid if not, before any run.
- Q4 Any engine change needed for a full-rank B (e.g., conditioning of the Stein estimate, PI
  joint truncation with a nonzero tail)?

## X9 GO (22:35 CDT 11/05) — author-approved; NPG/PI with approximately low-rank B

Your X9 QUERY answer is ACCEPTED as the basis of the protocol. The author approved X9 with:

- **Grid (pre-registered, not to be changed after any result):** alpha in {0, 0.05, 0.1, 0.2, 0.4},
  tau_2^2 = 22 alpha^2 in {0, 0.055, 0.22, 0.88, 3.52}. alpha = 0 is the X6b n = m = 24 cell, reused
  by reference in full (all rungs, all failures), as in your Q2 identity list. alpha = 0.4 is a
  pre-registered large-tail control.
- **Cap: 50 SU** (formal 46.93 + pilot 1 + report 2). If a revised resource plan exceeds the cap,
  stop and report; no automatic retries, no outcome-dependent cuts.
- **Everything frozen from X6b n24** except B: family S, systems 301-308, seeds 1701-1704, eta = 0.2,
  nu = 1, H = 16, burn/baseline blocks, NPG 16 / PI 8 updates, N_cal = 524,288 and the four integer
  rung schedules, pairing namespaces, k = 2 for both truncated arms. B = B_X6b + alpha U_tail V_tail^T
  from the original frozen streams, via a new versioned wrapper that writes only to a new X9 root.
- **Order:** (1) write PROTOCOL_v1 with the frozen ids, hashes, wrapper, and pilot checks;
  (2) pilot = resource/equivalence only (your 4-job plan), no gap-based selection; (3) report the pilot
  and wait for my PILOT ACCEPTED; (4) formal; (5) report.
- **Report (per alpha, algorithm, rung, arm):** absolute and relative gap medians and IQR, stable/full
  counts, first-failure stages, paired dense/truncated ratio medians with system-level paired bootstrap
  CI (failure-inclusive and both-stable versions), and the transitions per arm. Per alpha, recompute
  K*, P*, J* and g(K0) for that B (evaluation only). Redundant-cost share: alpha = 0 from the saved X6b
  values, N/A for alpha > 0 (no complement energy in the main tables). Also export one tidy CSV with
  the same columns as X6b-report-v1/summary.csv plus `alpha` and `tau2_sq`, and a CSV of the derived
  "transitions to match the dense gap at N_cal" (log-log interpolation between rungs, left/right
  censoring flagged), computed exactly as figs/data/X6b_transitions_saved_derived.csv.
- Wording in the report: X9 is an empirical scan outside the certified conditions of Theorem 3
  (fixed k = 2, empirical schedule, large tail). Do not describe it as a verification of the theorem.

## X9 PILOT ACCEPTED (23:00 CDT 11/05)

PILOT ACCEPTED X9. Reviewed PILOT_REPORT_v1: 8/8 bitwise equivalence PASS, no performance read
out, RSS headroom 93.8%, wall guards within limits, plan 49.933/50 SU. Proceed to FORMAL exactly as
in prepared-formal-v1 (formal config SHA256 580561a7...). Then REPORT as in X9 GO.

## X10 GO (23:00 CDT 11/05) — densify the main-text figures (author-approved, run directly)

Author request: the main-text figures have only four points per curve. Add points to every panel,
using exactly the frozen engines, families, systems, seeds, pairing and analysis of the original
experiments. **New configurations only. Every existing result is reused by reference and never
rerun or changed.** No outcome-dependent choice of configurations, no retuning, every failure kept.
The author asked to run without a further approval round: after PROTOCOL and a pilot whose checks
are fixed below, proceed to FORMAL automatically if and only if every pilot check passes and the
plan is within the cap. Otherwise stop and report. Run X9 FORMAL first, or concurrently if the
global concurrency policy allows.

### X10a — CE (cheap; local or Grace, your choice of the cheaper; no Grace SU if local)
- (a) X8 extension (Fig. 1(a), n = m = 48, same 8 systems sharing A, U, V, same seeds, N grid
  2^9..2^18 as nested prefixes, dense and every fixed order k = 1..47 recorded as in X8):
  exact family rank B = k for k in {3, 6, 12, 24}; geometric family sigma_j = rho^(j-1) for
  rho in {0.4, 0.6, 0.75, 0.85} (expected k_eps(B) at eps = 0.01: 3, 5, 10, 19; please verify from
  the spectrum). Sample cost at eps in {0.01, 0.005} with the X8 interpolation and censoring rules.
- (b) X6a family S extension (Fig. 1(b), rank B = 2, same construction and certificate class):
  n = m in {16, 20, 30, 42, 60, 84, 96}. Use the X6a N grid; for n >= 60 append powers of 2 up to
  2^20, fixed before any run. Dense and rank-2 CE on the same fits; sample cost at eps = 0.01 with
  the same interpolation as figs/data/X6a_sample_cost_derived.csv; censored if not reached.
- (c) X1 extension (Fig. 1(c)): n = 12, r = 2, null scale 0.25, m - r in {1, 3, 5, 6, 8, 9}
  (so that m - r = 1..10 together with the existing {2, 4, 7, 10}), N in {4096, 8192}, formal
  systems 101-108 and seeds 1001-1004 construction, CE only, normalized redundant cost
  N D(K)/v_star median and IQR for dense and truncated, exactly as X1_normalized_statistics.csv.

### X10b — NPG and PI (Grace)
- X6b family, systems, seeds, engine, eta = 0.2, H = 16, burn-in/baseline blocks, NPG 16 / PI 8
  stages, pairing namespaces and N_cal for every n in {24, 36, 48, 72}, unchanged.
- New rungs N_cal/2, N_cal/8, N_cal/32, N_cal/128, N_cal/256, constructed exactly as the X6b rungs
  (same stage-growth rule and integer rounding), both algorithms, both arms, all n. Together with
  the reused rungs N_cal/64, /16, /4, 1 this gives a factor-2 ladder of nine rungs.
- Pilot: (i) rerun one existing X6b path (one system/seed, smallest rung, both algorithms) and
  require bitwise equality with the saved X6b record; (ii) time the full set of new rungs for one
  n = 72 path per algorithm. Resource checks as in X9 (1.20 x body + 30 s <= wall, RSS <= 80%).
- Cap: 160 SU for X10b (pilot + formal + report). My rough estimate from X6b (242 SU for rung sum
  1.328) is about 125 SU for the added rung sum 0.668. If your plan exceeds the cap, stop and report.
- Target completion: Sun 11/08 18:00 CT. If the global concurrency limit makes this impossible,
  report the plan and the concurrency it would need, and wait.

### Report (both parts)
- X10a: CSVs with the same columns as figs/data/X8_sample_cost.csv, X6a_sample_cost_derived.csv
  and X1_normalized_statistics.csv, new rows only plus a merged copy with the existing rows
  (existing rows byte-identical), all failures and censoring flags.
- X10b: summary.csv with exactly the X6b-report-v1/summary.csv columns (new rungs only, plus a
  merged nine-rung copy with existing rows byte-identical), stable counts, failure lists, and
  transitions_saved_derived.csv recomputed on the nine-rung ladder with the same cross arithmetic
  as figs/make_figs.py (also the original four-rung values for comparison), censoring flags kept.
- Wording: descriptive densification of existing experiments; no new claim, no theorem
  verification. Do not edit the paper.

## X10 DECISIONS (00:35 CDT 11/06)

### X10a — corrected pilot AUTHORIZED
Reviewed "X10a PILOT failure": the stop was a missing `import json` in the portable wrapper; the
extracted `model`/`ce_prefixes` source texts, `run_shared_ce`, `run_x8` and the equivalence routine
are unchanged, pilot ids/seeds/grids are unchanged, and no formal observation was collected.
AUTHORIZED: run the remaining S (n96, sys 9902, seed 7702) and X1 (n12 m11, sys 9903, seed 7703)
checks with ce-src-v2 / ce-config-protocol-v2 in new ce-pilot-v2 paths; reuse the completed X8
pilot receipt (SHA256 bed83fe2...) by reference. Keep the failed v1 attempt and disclose it in the
report. Then FORMAL automatically iff every fixed check passes, exactly as in X10 GO.

### X10b — bounded pilot AUTHORIZED, cap clarified
- AUTHORIZED: the pilot exactly as you proposed (4.166667 requested SU): one equivalence replay
  (n24, s301, seed1701, rung 1/64, both algorithms) and two n72 timing tasks over all five new rungs
  (pilot system 9102 / seed 9801, one algorithm each), after X9's last array, global <= 8.
- Cap clarification: the 160-SU cap applies to the forecast of *actual* Slurm elapsed spend
  (measured pilot body seconds extrapolated to every formal task, plus the pilot and the report
  reserve). The *requested* allocation may reach 200 SU to cover the frozen 1.20 x body + 30 s
  wall guards and minute rounding.
- Proceed to FORMAL automatically iff all pilot checks pass, the measured actual-spend forecast is
  <= 160 SU, and the requested upper total is <= 200 SU. Otherwise stop and report.
- Submission order: n72, n48, n36, n24 (so the cells of Fig. 2(a,b) finish first). No change to
  science, seeds or rungs; global concurrency <= 8 unchanged.

## X10b cap — author confirmed (02:20 CDT 11/06)
The author confirmed the clarified X10b gates: actual-spend forecast <= 160 SU and requested upper
<= 200 SU. No other change.

## X10b corrected pilot AUTHORIZED (06:10 CDT 11/06)

Reviewed "X10b PILOT failure" and its accounting reconciliation: the stop was a missing remote
reference file (old X6b arrays no longer on Grace scratch), not a failed equality; the completed NPG
replay is bitwise equal to the original record. AUTHORIZED as proposed in CORRECTION_PROPOSAL_v2:
(1) run the metadata preflight (all 50 reference files against their original SHA256 from the
local X6b delivery, all 32 saved NPG arrays, unchanged science, ledger history, X9 complete);
(2) one 10-min job comparing the saved v1 NPG arrays to the verified reference copies (no NPG
rerun) and running only the PI replay; (3) the two n72 timing tasks. Additional requested upper
4.166667 SU. Gates for FORMAL unchanged: every check PASS, measured actual-spend forecast <= 160 SU,
requested upper <= 200 SU, deadline feasible, global <= 8, submission order n72, n48, n36, n24.
Also: before FORMAL, confirm that neither the formal runs nor the report read any other old
remote file (the nine-rung merge must use the local X6b-report-v1 records), and copy every new
X9/X10b raw output to the E-drive delivery promptly, since Grace scratch evidently purges files.

## X11 + X12 GO and CONCURRENCY (13:15 CDT 11/06) — author-approved, run directly, results ASAP

The author wants results fast and allows up to 64 concurrent Grace tasks in total (all of X10b,
X12 and anything else of ours). Same discipline as X10: new configurations only, every existing
result reused by reference and never rerun or changed, no outcome-dependent choices, every failure
kept. PROTOCOL -> pilot with fixed checks -> FORMAL automatically iff every check passes and the
plan is within the cap -> REPORT. Otherwise stop and report.

### Concurrency (applies now)
- Raise the throttle of the running/pending X10b arrays to 32 (scontrol update ArrayTaskThrottle)
  and let independent X10b arrays run concurrently instead of the serial afterok chain, if this
  can be done without resubmitting or changing any task. Total of our running Grace tasks <= 64.
  X10b gates (actual <= 160 SU, requested <= 200 SU) unchanged.

### X11 — CE one-factor dimension sweeps (local, 0 Grace SU; parallel local workers allowed,
one BLAS thread each)
Purpose: with n = m both dimensions change; separate the input side from the state side.
Family S CE exactly as X6a/X10a (same construction, certificate class, systems 301..308, seed
construction, burn-in 512, nested prefixes, dense and rank-2 CE from the same fit), rank B = 2:
- Sweep M (input dimension): n = 48, m in {4, 6, 8, 12, 16, 24, 32}; n = m = 48 reused from X6a.
- Sweep N (state dimension): m = 16, n in {24, 32, 48, 64, 96}; n = m = 16 reused from X10a.
- N grid: the X6a grid 2048..524288 (factor 4); append 1048576 if n + m >= 120 (fixed now).
- Sample cost at absolute eps = 0.01 with the same interpolation/censoring as
  figs/data/X6a_sample_cost_derived.csv; also the dense/truncated paired gap ratio at each N.
- If the family-S construction or certificate rule refers to n = m anywhere, report before running.
- Report: CSV with the X6a_sample_cost_derived.csv columns plus m (new rows only, and a merged copy
  with the reused rows), stable counts, failures, censoring.

### X12 — NPG/PI at n = m = 60 (Grace)
- X6b family, engine, eta = 0.2, H = 16, burn/baseline blocks, NPG 16 / PI 8 stages, pairing
  namespaces, systems/seeds construction, rank B = 2, k = 2, unchanged.
- N_cal for n = 60 from the registered X6b calibration rule applied exactly as for the other n
  (pilot systems only, no formal data); report the rule and the resulting N_cal.
- All nine rungs N_cal/256, /128, /64, /32, /16, /8, /4, /2, 1, both algorithms, both arms,
  constructed as in X6b/X10b.
- Pilot: calibration + timing on pilot systems; engine identity may be shown by hash identity with
  the X10b-verified sources (no new replay needed if hashes match).
- Cap: actual-spend forecast <= 230 SU, requested upper <= 300 SU (pilot + formal + report).
  My estimate is 110-220 SU actual depending on N_cal.
- Report: summary.csv rows with exactly the X6b columns for n = 60, merged with the nine-rung
  X6b+X10b table, and transitions_saved_derived.csv for n = 60 with the same cross arithmetic.
- Copy raw outputs to E promptly as in X10b.

Wording for both: descriptive experiments; no theorem verification claim. Do not edit the paper.

## X11 construction ACCEPTED; X10b scheduling OK (13:30 CDT 11/06)
- X11: the rectangular extension in CONSTRUCTION_NOTICE_v1.md is ACCEPTED as proposed (A and U
  streams preserved, V = haar(rng(3,n,m,system), m), B = U_2 V_2^T, R = I_m, K0 = 0; square cases
  must reproduce the original inputs exactly, checked in the pilot). With n = 48 fixed, A and U are
  identical across m, which is what we want. Proceed: pilot fixed checks -> FORMAL automatically.
- X10b: the two-lane plan with throttles 32 + 32 (no cancellation, no resubmission, no task change)
  is OK. X12 then needs free slots; keep our total <= 64.

## X12 submission correction AUTHORIZED (13:50 CDT 11/06)
Reviewed "X12 PILOT submission rejected before allocation": Grace rejected sbatch before any
allocation because --ntasks was missing. AUTHORIZED as in SUBMISSION_CORRECTION_PROPOSAL_v2.md:
add only --ntasks=1 in a new submission helper/receipt namespace; one CPU / 2 GiB, walls, ids,
seeds, grid, dependencies and requested 2.75 SU unchanged. Check the same flag in the timing-pilot
and formal templates before they are submitted, so that the same rejection cannot recur.
X11 REPORT reviewed: accepted (rounding reconciliation of the reused square-48 crossing noted).

## X12 v3 dependency correction AUTHORIZED (14:57 CDT 11/06)
Reviewed "X12 PILOT stale dependency rejection before allocation" and "queue-preflight
clarification": the first eight n72-PI predecessors are COMPLETED in sacct and their dependency
records have expired. AUTHORIZED as in SUBMISSION_CORRECTION_PROPOSAL_v3.md with the v3r2
helper/runner: after verifying the eight predecessors COMPLETED, no X12 allocation or output,
and global running + 8 <= 64, submit the calibration without the stale dependency; resolution
keeps afterok on the new calibration array. Everything else unchanged (--ntasks=1, 1 CPU / 2 GiB,
walls, seeds, grid, thresholds, sources, 2.75 SU; timing pilot on medium with --ntasks=1, 6 SU).
X10b FORMAL DONE noted (formal 119.33 SU + pilot 2.26 SU, within the 160 SU forecast cap).

## Connection restored (17:15 CDT 11/06)
The author reports that the Cisco VPN is connected again. Please re-verify the Grace connection
yourself (read-only first), recheck the X10b REPORT jobs (20422511..20422515) and the global
running count, then continue as already authorized: fetch the X10b report (quick tables first, then
the chunked full archive), and submit the X12 calibration with the v3r2 helper. No other change.

## X10b REPORT ACCEPTED; X11 supplement acknowledged; X12 resource rule accepted (23:45Z 11/06)

X10b: report accepted. I reproduced all eight nine-rung saving factors from summary_merged_nine_rungs.csv with the paper's cross function (NPG 2.892/4.039/4.949/6.690, PI 22.62/31.85/43.63/68.63; no censoring), and the four original rungs match X6b byte-for-byte in the medians. Integrated into the paper: Fig. 2 now shows nine budgets, Sec. 6 and App. H.3 report the full failure counts (dense NPG 0/32 at 1/256 and 1/128; dense PI 0/32 up to 1/32 and 58/128 at 1/16; truncated PI 1152/1152; truncated NPG fails only 13/32 at n=24, 1/256). App. H.3 discloses that the budgets with j in {1,3,5,7,8} were added later with the same systems, seeds and analysis. No further X10b work needed.

X11 uncertainty supplement: acknowledged as a post-hoc, clearly labeled supplement. The paper does not use it; keep it in the record. No action.

X12 (n=60): the frozen resource rule (max of the n60 timing-pilot body and the historical floor, ceil((1.20*body+30)/60) wall, all pilots + prep + 8 SU report reserve inside the gates) is accepted. When both timing pilots pass their fixed checks and the forecast is within actual <= 230 SU and requested <= 300 SU, proceed to FORMAL without waiting for another review; total concurrency <= 64. Then REPORT with the same nine-rung products as X10b (summary, transitions_saved_derived, failure counts). If any gate fails, stop and report.

## X12 storage-failure recovery: ruling (01:40Z 11/07)

Your stop, diagnosis, and disclosure are accepted; the omitted remote file-quota gate is recorded as a protocol omission, not a scientific result.

1. Evidence first, as you proposed: seal the failed v1 partial tree and provenance into a new home transit archive, copy to E, verify every member. 0 SU. Do NOT delete, move, or modify anything on scratch or home (no cleanup of old X6b/X10b/X11 files, even though they are verified on E). Deleting cluster data needs the user's explicit consent, which we do not have.

2. Accounting ruling. Actual cap unchanged: cumulative X12 actual <= 230 SU, including all pilots, model prep, the failed formal charges, the recovery, and the report. Requested cap: 300 SU applies to (settled actual of every finished/failed allocation) + (requested upper of outstanding allocations) + (8 SU report reserve). Released reservations of the failed allocations are not counted twice. Record both books explicitly in the next accounting snapshot.

3. Recovery plan (authorized subject to the gates below): fresh namespace on home (or any location you can prove has room without deleting anything), unchanged collector/learner/estimator sources, completed-stage raw bytes appended to per-task tar files so that active loose files stay small. Reuse an old path only if it is complete and its bytes are SHA-verified; rerun every incomplete path from its start with the registered seeds (no mid-path resume). Wasted failed compute stays in the SU books; it is not counted as training transitions.

4. Gates before FORMAL: (a) a metadata-only or minimal pilot that measures peak loose-file count and peak bytes per task, and a forecast for all 64 concurrent tasks plus the report that stays below 80% of the free file slots and free bytes of the chosen location; (b) quota-aware df/quota check read immediately before submission; (c) the cost books in item 2. If all pass, proceed to FORMAL and REPORT without another review; global concurrency <= 64. If the storage forecast does not fit anywhere without deleting data, STOP and report the numbers; I will take it to the user.

## X12 storage correction: no REVISE (02:40Z 11/07)

The storage-only correction (fresh MDT0 directory via lfs mkdir -i0 -c1, in-memory NPZ to per-task tar + journal, node-local caches, no memfd/named fallback, per-MDT and global 80% gates, reuse of the 296 SHA-verified complete paths, no mid-path resume) is within the 01:40Z ruling. No additional ruling needed. Proceed through the IO pilot and the fixed gates; FORMAL and REPORT only if all pass. Still no deletion, move, or modification of existing cluster data.

## X12 MDT placement: substitution CONFIRMED (03:00Z 11/07)

Confirmed: one ordinary `mkdir` of a fresh namespace in home, then verify with `lfs getdirstripe -i` and `lfs getstripe -m` on one small file that both are on MDT0; flat file namespace for the IO pilot and all task outputs. Proceed only if both land on MDT0 and the per-MDT (MDT0 free slots) and global gates hold at 80% for all 64 tasks plus the report. No permission changes, no layout changes, no deletion or move of any existing file, including failed probe artifacts. If the placement probe fails or the forecast does not fit, STOP and report the numbers; I will take the storage question to the user. All numerical and accounting gates remain binding; FORMAL and REPORT follow automatically if all pass.

## X12 storage: USER AUTHORIZED scratch cleanup (03:20Z 11/07)

The user explicitly chose, in chat, to clean old raw experiment files on Grace scratch that are already backed up on E. This is the only deletion authorized, with these limits:

1. Scope: only raw output files of our own completed experiments under our own scratch experiment directories (prefer the X10b formal raw tree first, then X6b raw if needed). Never touch home, source code, configs, release packages, accounting records, the failed X12 v1 tree, or anything of other projects or other users.
2. Proof before deletion: build a deletion manifest (scratch path, size, SHA-256, matching E path and the existing E verification record). Immediately before deleting, re-hash each scratch file on Grace and delete it only if the hash equals the verified E copy. Any mismatch, missing E copy, or unreadable file: keep it and list it.
3. Delete only as much as needed: target about 20,000 freed file slots (enough for X12 plus a large margin), not a full cleanup. Delete files only; leave directories in place unless an empty directory itself blocks the quota.
4. Record: write the manifest, the per-file deletion log, and before/after quota-aware df to E. Report the number of files deleted, bytes freed, and the new scratch quota numbers.
5. Then run X12 on scratch with the existing gates: fresh flat namespace, IO pilot, per-MDT and global storage < 80% of the freed capacity, presubmission quota check, actual <= 230 SU cumulative, requested exposure <= 300. FORMAL and REPORT follow automatically if all pass; stop and report otherwise.

## X12 cleanup manifest CONFIRMED (03:45Z 11/07)

Confirmed, under the user's explicit 03:20Z authorization: unlink exactly the 20,000 X10b formal stage/checkpoint NPZ files listed in scratch-cleanup-proposal-20261107-v1/DELETE_CANDIDATES_v1.tsv (manifest SHA be2676d6...aa), each only after its immediate Grace SHA and identity check matches the sealed E delivery. Nothing outside the manifest; no directories; no retries of mismatches (keep and list them). Copy the per-file log and the before/after quota-aware df to E. Then proceed with the fresh flat scratch namespace, verify actual directory and file MDT placement, and run the IO pilot, storage gates (< 80% of freed slots per MDT and global), cost gates, FORMAL and REPORT as already authorized. Stop and report on any failed gate.
